# 一个猩际PTE流式刷题得分汇总小工具
## 使用方式
```bash
git clone "https://github.com/Frankenstein-xin/chrome-extensions.git"
```
- chrome地址栏输入`chrome://extensions/`
- 打开页面右上角的`开发者模式`开关
- 然后点击左上角的`加载已解压的扩展程序`
- 选取文件夹`chrome-extensions/xjpte`即可安装本扩展插件

## 如何弹出分数界面
- RS流式刷题完毕后单击chrome工具栏上本插件图标即可弹出得分汇总界面，其他页面上点击无效
- 为方便起见可以将本插件固定在工具栏
